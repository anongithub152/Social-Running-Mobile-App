angular.module('RUN')
	.controller('VirtualRunCtrl', function($scope) {
		var vm = this;
	});