//firebase.js
//Set this to your Firebase configuration from your Firebase app's console.
//Head to https://console.firebase.google.com/ select your Firebase app and then select "Add Firebase to your web app".
// Initialize Firebase
  var config = {
    apiKey: "AIzaSyDDKuig7uFEWHfIubYlLdG8I0oWtQQPkxo",
    authDomain: "run-app-c1981.firebaseapp.com",
    databaseURL: "https://run-app-c1981.firebaseio.com",
    storageBucket: "run-app-c1981.appspot.com",
    messagingSenderId: "1001112351360"
  };
  firebase.initializeApp(config);
